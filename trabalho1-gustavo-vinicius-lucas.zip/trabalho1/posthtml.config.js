module.exports = {
  plugins: {
    "posthtml-include": {}
  }
};