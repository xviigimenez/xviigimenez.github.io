/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["source/*.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

